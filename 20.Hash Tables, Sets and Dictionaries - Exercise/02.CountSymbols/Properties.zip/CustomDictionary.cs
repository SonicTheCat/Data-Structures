﻿public class CustomDictionary<TKey, TValue> : HashTable<TKey, TValue>
{

}